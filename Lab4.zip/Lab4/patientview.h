#ifndef PATIENTVIEW_H
#define PATIENTVIEW_H

#include <QWidget>
#include <QSqlTableModel>

namespace Ui {
class PatientView;
}

class PatientView : public QWidget
{
    Q_OBJECT

public:
    explicit PatientView(QWidget *parent = nullptr);
    ~PatientView();

    void refresh();

    int pendingEditId() const { return m_pendingEditId; }



private slots:
    void on_btDelete_clicked();
    void on_btAdd_clicked();
    void on_btEdit_clicked();
    void on_btSearch_clicked();

signals:
    void goPatientEditView();

private:
    Ui::PatientView *ui;

    QSqlTableModel *model = nullptr;

    int m_pendingEditId = 0;

};

#endif // PATIENTVIEW_H
