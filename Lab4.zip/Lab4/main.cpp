#include "masterview.h"
#include "dbmanager.h"

#include <QApplication>
#include <QMessageBox>
#include <QCoreApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QString dbPath = R"(C:\Users\27494\Desktop\Lab4\hospital.db)";

    if (!DbManager::instance().open(dbPath)) {
        QMessageBox::critical(nullptr, "DB Error", "无法打开数据库: " + dbPath);
        return 1;
    }

    MasterView w;
    w.show();
    return a.exec();
}
