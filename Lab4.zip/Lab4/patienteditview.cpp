#include "patienteditview.h"
#include "ui_patienteditview.h"
#include "dbmanager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDate>

PatientEditView::PatientEditView(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PatientEditView)
{
    ui->setupUi(this);

    // 保存按钮：pushButton
    connect(ui->pushButton, &QPushButton::clicked, this, [this]() {

        // 1) 从 UI 取值（你 UI 里的对象名就是这些）
        QString name = ui->lineEdit_2->text().trimmed();   // 姓名
        if (name.isEmpty()) {
            QMessageBox::warning(this, "提示", "姓名不能为空");
            return;
        }

        QString gender = ui->comboBox->currentText();      // 性别
        QString birth  = ui->dateEdit->date().toString("yyyy-MM-dd"); // 出生日期
        int height     = ui->spinBox->value();             // 身高
        int weight     = ui->spinBox_2->value();           // 体重
        QString phone  = ui->lineEdit_7->text().trimmed(); // 手机号
        QString idCard = ui->lineEdit_4->text().trimmed(); // 身份证

        // 2) 准备 SQL
        QSqlQuery q(DbManager::instance().db());

        if (m_id <= 0) {
            // --- 新增：INSERT ---
            q.prepare(
                "INSERT INTO patients(name, gender, birth_date, height, weight, phone, id_card) "
                "VALUES(?,?,?,?,?,?,?)"
                );
            q.addBindValue(name);
            q.addBindValue(gender);
            q.addBindValue(birth);
            q.addBindValue(height);
            q.addBindValue(weight);
            q.addBindValue(phone);
            q.addBindValue(idCard);

        } else {
            // --- 修改：UPDATE ---
            q.prepare(
                "UPDATE patients SET name=?, gender=?, birth_date=?, height=?, weight=?, phone=?, id_card=? "
                "WHERE id=?"
                );
            q.addBindValue(name);
            q.addBindValue(gender);
            q.addBindValue(birth);
            q.addBindValue(height);
            q.addBindValue(weight);
            q.addBindValue(phone);
            q.addBindValue(idCard);
            q.addBindValue(m_id);
        }

        // 3) 执行并处理错误
        if (!q.exec()) {
            QMessageBox::critical(this, "DB Error", q.lastError().text());
            return;
        }

        // 4) 通知外面：保存成功（MasterView 会返回上一页 + 刷新表）
        emit saved();
    });


    setWindowTitle("患者编辑");

    ui->comboBox->clear();
    ui->comboBox->addItems({"男","女"});

    // ID 一般不让手输
    ui->lineEdit->setReadOnly(true);

    connect(ui->pushButton,  &QPushButton::clicked, this, [this](){  // 保存
        // 调用 save 逻辑（下面写）
        // ...
    });

    connect(ui->pushButton_2,&QPushButton::clicked, this, [this](){  // 取消
        emit canceled();
    });
}
void PatientEditView::setPatientId(int id)
{
    m_id = id;

    if (m_id <= 0) {
        ui->lineEdit->clear();        // id
        ui->lineEdit_2->clear();      // name
        ui->lineEdit_4->clear();      // id_card
        ui->lineEdit_7->clear();      // phone
        ui->comboBox->setCurrentIndex(0);
        ui->dateEdit->setDate(QDate::currentDate());
        ui->spinBox->setValue(0);
        ui->spinBox_2->setValue(0);
        return;
    }

    QSqlQuery q(DbManager::instance().db());
    q.prepare("SELECT id, name, gender, birth_date, height, weight, phone, id_card FROM patients WHERE id=?");
    q.addBindValue(m_id);

    if (!q.exec()) {
        QMessageBox::critical(this, "DB Error", q.lastError().text());
        return;
    }
    if (!q.next()) {
        QMessageBox::warning(this, "提示", "找不到该患者记录");
        return;
    }

    ui->lineEdit->setText(q.value(0).toString());
    ui->lineEdit_2->setText(q.value(1).toString());
    ui->comboBox->setCurrentText(q.value(2).toString());
    ui->dateEdit->setDate(QDate::fromString(q.value(3).toString(), "yyyy-MM-dd"));
    ui->spinBox->setValue(q.value(4).toInt());
    ui->spinBox_2->setValue(q.value(5).toInt());
    ui->lineEdit_7->setText(q.value(6).toString());
    ui->lineEdit_4->setText(q.value(7).toString());
}


PatientEditView::~PatientEditView()
{
    delete ui;
}


