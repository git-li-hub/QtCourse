#ifndef PATIENTEDITVIEW_H
#define PATIENTEDITVIEW_H

#include <QWidget>

namespace Ui {
class PatientEditView;
}

class PatientEditView : public QWidget
{
    Q_OBJECT

public:
    explicit PatientEditView(QWidget *parent = nullptr);
    ~PatientEditView();

    void setPatientId(int id);   // id=0 表示新增

signals:
    void saved();
    void canceled();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::PatientEditView *ui;

    int m_id = 0;

};

#endif // PATIENTEDITVIEW_H
