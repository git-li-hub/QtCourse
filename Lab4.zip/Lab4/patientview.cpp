#include "patientview.h"
#include "ui_patientview.h"
#include "dbmanager.h"
#include <QAbstractItemView>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>

PatientView::PatientView(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PatientView)
{
    ui->setupUi(this);

    model = new QSqlTableModel(this, DbManager::instance().db());
    model->setTable("patients");
    model->setEditStrategy(QSqlTableModel::OnFieldChange); // 直接编辑就写回DB
    model->select();

    ui->tableView->setModel(model);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
}

void PatientView::refresh() {
    if (model) model->select();
}

PatientView::~PatientView()
{
    delete ui;
}

void PatientView::on_btDelete_clicked()
{
    auto idx = ui->tableView->currentIndex();
    if (!idx.isValid()) {
        QMessageBox::warning(this, "提示", "请先选中一行");
        return;
    }

    int row = idx.row();
    int id = model->data(model->index(row, 0)).toInt(); // 假设第0列是id（通常是）

    if (QMessageBox::question(this, "确认", "确定删除该患者？") != QMessageBox::Yes)
        return;

    QSqlQuery q(DbManager::instance().db());
    q.prepare("DELETE FROM patients WHERE id=?");
    q.addBindValue(id);

    if (!q.exec()) {
        QMessageBox::critical(this, "DB Error", q.lastError().text());
        return;
    }

    model->select();
}

void PatientView::on_btAdd_clicked()
{
    m_pendingEditId = 0;           // 0 = 新增
    emit goPatientEditView();      // 让 MasterView 打开编辑页 :contentReference[oaicite:6]{index=6}
}

void PatientView::on_btEdit_clicked()
{
    auto idx = ui->tableView->currentIndex();
    if (!idx.isValid()) {
        QMessageBox::warning(this, "提示", "请先选中一行再修改");
        return;
    }
    int row = idx.row();
    m_pendingEditId = model->data(model->index(row, 0)).toInt(); // 第0列为id :contentReference[oaicite:7]{index=7}
    emit goPatientEditView();
}

void PatientView::on_btSearch_clicked()
{
    QString key = ui->txtSearch->text().trimmed();
    if (key.isEmpty()) {
        model->setFilter("");
        model->select();
        return;
    }

    QString safe = key;
    safe.replace("'", "''"); // 防止引号破坏 SQL

    // 你可以按自己表字段名调整：name/phone/id_card
    model->setFilter(QString("name LIKE '%%1%' OR phone LIKE '%%1%' OR id_card LIKE '%%1%'").arg(safe));
    model->select();
}
