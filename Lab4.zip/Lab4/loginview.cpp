#include "loginview.h"
#include "ui_loginview.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include "dbmanager.h"

LoginView::LoginView(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::LoginView)
{
    ui->setupUi(this);
}

LoginView::~LoginView()
{
    delete ui;
}

void LoginView::on_btSignin_clicked()
{
    QString user = ui->inputUserName->text().trimmed();
    QString pass = ui->inputUserPassword->text();

    QSqlQuery q(DbManager::instance().db());

    if (!q.prepare("SELECT 1 FROM users WHERE username = :u AND password = :p")) {
        QMessageBox::critical(this, "DB Error", q.lastError().text());
        return;
    }

    q.bindValue(":u", user);
    q.bindValue(":p", pass);

    if (!q.exec()) {
        QMessageBox::critical(this, "DB Error", q.lastError().text());
        return;
    }

    if (q.next()) {
        emit loginSuccess();
    } else {
        QMessageBox::warning(this, "登录失败", "用户名或密码错误");
        emit loginFailed();
    }
}

