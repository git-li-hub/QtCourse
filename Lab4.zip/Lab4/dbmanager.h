#pragma once
#include <QString>
#include <QSqlDatabase>

class DbManager {
public:
    static DbManager& instance();

    bool open(const QString& dbPath);
    QSqlDatabase db() const { return m_db; }
    bool isOpen() const { return m_db.isOpen(); }

private:
    DbManager() = default;
    QSqlDatabase m_db;
};
