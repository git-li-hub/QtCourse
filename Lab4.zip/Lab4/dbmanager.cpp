#include "dbmanager.h"
#include <QSqlError>
#include <QDebug>

DbManager& DbManager::instance() {
    static DbManager inst;
    return inst;
}

bool DbManager::open(const QString& dbPath) {
    if (m_db.isOpen()) return true;

    m_db = QSqlDatabase::addDatabase("QSQLITE", "main");
    m_db.setDatabaseName(dbPath);

    if (!m_db.open()) {
        qDebug() << "Open DB failed:" << m_db.lastError().text();
        return false;
    }
    return true;
}
