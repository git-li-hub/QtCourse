#include "linenumberarea.h"
#include "mdichild.h"
#include <QPainter>

LineNumberArea::LineNumberArea(MdiChild *editor)
    : QWidget(editor), codeEditor(editor)
{
}

QSize LineNumberArea::sizeHint() const
{
    if (codeEditor) {
        return QSize(codeEditor->lineNumberAreaWidth(), 0);
    }
    return QSize(0, 0);
}

void LineNumberArea::paintEvent(QPaintEvent *event)
{
    if (codeEditor) {
        codeEditor->lineNumberAreaPaintEvent(event);
    }
}
