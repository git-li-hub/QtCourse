#ifndef MDICHILD_H
#define MDICHILD_H

#include <QMenu>
#include <QPlainTextEdit>
#include <QWidget>
#include <QColor>  // 添加这个
#include <QTextFormat>  // 添加这个

class LineNumberArea;

class MdiChild : public QPlainTextEdit
{
    Q_OBJECT

private:
    QString curFile;  // 当前文件路径
    bool isUntitled;  // 作为当前文件是否被保存到硬盘的标志
    LineNumberArea *lineNumberArea;  // 行号区域

    bool maybeSave();                              // 是否需要保存
    void setCurrentFile(const QString& fileName);  // 设置当前文件
    bool saveFile(const QString& fileName);        // 保存文件

protected:
    void closeEvent(QCloseEvent* event) override;          // 关闭事件
    void contextMenuEvent(QContextMenuEvent* e) override;  // 右键菜单事件
    void resizeEvent(QResizeEvent* event) override;        // 重设大小事件

public:
    explicit MdiChild(QWidget* parent = nullptr);
    ~MdiChild();

    // 文件操作
    void newFile();                            // 新建文件
    bool loadFile(const QString& fileName);    // 加载文件
    bool save();                               // 保存操作
    bool saveAs();                             // 另存为操作
    QString userFriendlyCurrentFile();         // 提取文件名
    QString currentFile() { return curFile; }  // 返回当前文件路径

    // 格式设置
    void setFontSize(int size);                // 设置字体大小
    void setFontColor(const QColor &color);    // 设置字体颜色
    void setBackgroundColor(const QColor &color); // 设置背景色
    void setLineWrap(bool wrap);               // 设置自动换行
    bool getIsModified() const { return document()->isModified(); } // 获取修改状态

    // 行号相关
    int lineNumberAreaWidth();
    void setLineNumberVisible(bool visible);
    bool isLineNumberVisible() const;

    // QPlainTextEdit 方法包装
    QTextBlock firstVisibleBlock() const;
    QRectF blockBoundingGeometry(const QTextBlock &block) const;
    QPointF contentOffset() const;
    QRectF blockBoundingRect(const QTextBlock &block) const;
    void lineNumberAreaPaintEvent(QPaintEvent *event);


private slots:
    void documentWasModified();                // 文档被更改时，窗口显示更改状态标志
    void updateLineNumberAreaWidth(int newBlockCount);
    void updateLineNumberArea(const QRect &rect, int dy);
    void highlightCurrentLine();
};

#endif  // MDICHILD_H
