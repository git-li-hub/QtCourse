#include "mdichild.h"
#include "linenumberarea.h"

#include <QApplication>
#include <QCloseEvent>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QMessageBox>
#include <QPushButton>
#include <QTextStream>
#include <QMenu>
#include <QAction>
#include <QContextMenuEvent>
#include <QPainter>
#include <QTextBlock>
#include <QTextCursor>
#include <QTextCharFormat>
#include <QPlainTextEdit>  // 添加这个
// 是否需要保存
// 提取文件保存方法


bool MdiChild::maybeSave()
{
    if (document()->isModified()) {
        QMessageBox box;
        box.setWindowTitle(tr("多文档编辑器"));
        box.setText(tr("是否保存对\"%1\"的更改？").arg(userFriendlyCurrentFile()));
        box.setIcon(QMessageBox::Warning);
        QPushButton* yesBtn = box.addButton(tr("是(&Y)"), QMessageBox::YesRole);
        box.addButton(tr("否(&N)"), QMessageBox::NoRole);
        QPushButton* cancelBtn = box.addButton(tr("取消"), QMessageBox::RejectRole);
        box.exec();

        if (box.clickedButton() == yesBtn) {
            return saveFile(curFile);  // 调用提取出来的 saveFile 方法
        } else if (box.clickedButton() == cancelBtn) {
            return false;
        }
    }
    return true;
}


// 设置当前文件
void MdiChild::setCurrentFile(const QString& fileName)
{
    // canonicalFilePath()可以除去路径中的符号链接，"."和".."等符号
    curFile = QFileInfo(fileName).canonicalFilePath();
    // 文件已经被保存过了
    isUntitled = false;
    // 文档没有被更改过
    document()->setModified(false);
    // 窗口不显示被更改标志
    setWindowModified(false);
    // 设置窗口标题，userFriendlyCurrentFile() 函数返回文件名
    setWindowTitle(userFriendlyCurrentFile() + "[*]");
}

// 关闭操作，在关闭事件中执行
void MdiChild::closeEvent(QCloseEvent* event)
{
    if (maybeSave()) {
        event->accept();
    } else {
        // 提供更多用户反馈
        QMessageBox::information(this, tr("未保存的更改"), tr("您的更改尚未保存，已取消关闭操作。"));
        event->ignore();
    }
}



// 右键菜单事件
void MdiChild::contextMenuEvent(QContextMenuEvent* e)
{
    // 创建菜单，并向其中添加动作
    QMenu* menu = new QMenu;
    QAction* undo = menu->addAction(tr("撤销(&U)"), this, SLOT(undo()), QKeySequence::Undo);
    undo->setEnabled(document()->isUndoAvailable());
    QAction* redo = menu->addAction(tr("恢复(&R)"), this, SLOT(redo()), QKeySequence::Redo);
    redo->setEnabled(document()->isRedoAvailable());
    menu->addSeparator();
    QAction* cut = menu->addAction(tr("剪切(&T)"), this, SLOT(cut()), QKeySequence::Cut);
    cut->setEnabled(textCursor().hasSelection());
    QAction* copy = menu->addAction(tr("复制(&C)"), this, SLOT(copy()), QKeySequence::Copy);
    copy->setEnabled(textCursor().hasSelection());
    menu->addAction(tr("粘贴(&P)"), this, SLOT(paste()), QKeySequence::Paste);
    QAction* clear = menu->addAction(tr("清空"), this, SLOT(clear()));
    clear->setEnabled(!document()->isEmpty());
    menu->addSeparator();
    QAction* select = menu->addAction(tr("全选"), this, SLOT(selectAll()), QKeySequence::SelectAll);
    select->setEnabled(!document()->isEmpty());
    // 获取鼠标的位置，然后在这个位置显示菜单
    menu->exec(e->globalPos());
    // 最后销毁这个菜单
    delete menu;
}

MdiChild::MdiChild(QWidget* parent) : QPlainTextEdit(parent)
{
    // 设置在子窗口关闭时销毁这个类的对象
    setAttribute(Qt::WA_DeleteOnClose);
    // 初始 isUntitled 为 true
    isUntitled = true;

    lineNumberArea = new LineNumberArea(this);

    // 连接信号和槽来更新行号 - 使用 QPlainTextEdit 的信号
    connect(this, &QPlainTextEdit::blockCountChanged, this, &MdiChild::updateLineNumberAreaWidth);
    connect(this, &QPlainTextEdit::updateRequest, this, &MdiChild::updateLineNumberArea);
    connect(this, &QPlainTextEdit::cursorPositionChanged, this, &MdiChild::highlightCurrentLine);

    // 初始更新
    updateLineNumberAreaWidth(0);
    highlightCurrentLine();

    // 默认不显示行号
    setLineNumberVisible(false);
}

MdiChild::~MdiChild()
{
    delete lineNumberArea;
}

// 计算行号区域宽度
int MdiChild::lineNumberAreaWidth()
{
    int digits = 1;
    int max = qMax(1, document()->blockCount());
    while (max >= 10) {
        max /= 10;
        ++digits;
    }

    int space = 10 + fontMetrics().horizontalAdvance(QLatin1Char('9')) * digits;
    return space;
}

// 更新行号区域宽度
void MdiChild::updateLineNumberAreaWidth(int /* newBlockCount */)
{
    if (isLineNumberVisible()) {
        setViewportMargins(lineNumberAreaWidth(), 0, 0, 0);
    } else {
        setViewportMargins(0, 0, 0, 0);
    }
}

// 更新行号区域
void MdiChild::updateLineNumberArea(const QRect &rect, int dy)
{
    if (dy != 0) {
        lineNumberArea->scroll(0, dy);
    } else {
        lineNumberArea->update(0, rect.y(), lineNumberArea->width(), rect.height());
    }

    if (rect.contains(viewport()->rect())) {
        updateLineNumberAreaWidth(0);
    }
}

// 重设大小事件
void MdiChild::resizeEvent(QResizeEvent *event)
{
    QPlainTextEdit::resizeEvent(event);

    if (isLineNumberVisible()) {
        QRect cr = contentsRect();
        lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
    }
    // 确保调整完大小后更新行号区域
    updateLineNumberAreaWidth(0);  // 这里是调用来更新行号区域的
}


// 行号绘制事件
void MdiChild::lineNumberAreaPaintEvent(QPaintEvent *event)
{
    if (!isLineNumberVisible()) return;

    QPainter painter(lineNumberArea);
    painter.fillRect(event->rect(), QColor(240, 240, 240));

    // 获取当前可见的文本块
    QTextBlock block = firstVisibleBlock();
    if (!block.isValid()) return;

    // 获取第一个可见块的位置
    QPointF contentOffset = this->contentOffset();
    qreal top = blockBoundingGeometry(block).translated(contentOffset).top();
    qreal bottom = top + blockBoundingRect(block).height();

    painter.setPen(Qt::darkGray);
    QFont font = this->font();
    font.setPointSize(font.pointSize() - 1);
    painter.setFont(font);

    // 绘制可见块的行号
    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            QString number = QString::number(block.blockNumber() + 1);
            painter.drawText(0, static_cast<int>(top), lineNumberArea->width() - 5,
                             fontMetrics().height(), Qt::AlignRight, number);
        }

        block = block.next();
        top = bottom;
        bottom = top + blockBoundingRect(block).height();

        // 安全检查，避免无限循环
        if (!block.isValid()) break;
    }
}

// 设置行号显示状态
void MdiChild::setLineNumberVisible(bool visible)
{
    // 设置行号区域的可见性
    lineNumberArea->setVisible(visible);
    updateLineNumberAreaWidth(0);  // 更新行号区域的宽度
}


// 获取行号显示状态
bool MdiChild::isLineNumberVisible() const
{
    return lineNumberArea->isVisible();
}

// 高亮当前行
void MdiChild::highlightCurrentLine()
{
    QList<QTextEdit::ExtraSelection> extraSelections;

    if (!isReadOnly()) {
        QTextEdit::ExtraSelection selection;
        QColor lineColor = QColor(Qt::yellow).lighter(160);  // 选中的行背景色
        selection.format.setBackground(lineColor);
        selection.format.setProperty(QTextFormat::FullWidthSelection, true);  // 使选择覆盖整行
        selection.cursor = textCursor();
        selection.cursor.clearSelection();  // 清除光标选择
        extraSelections.append(selection);
    }

    setExtraSelections(extraSelections);  // 设置额外的选择
}


// 新建文件操作
void MdiChild::newFile()
{
    // 设置窗口编号，因为编号一直被保存，所以需要使用静态变量
    static int sequenceNumber = 1;
    // 新建的文档没有被保存过
    isUntitled = true;
    // 将当前文件命名为未命名文档加编号，编号先使用再加 1
    curFile = tr("未命名文档%1.txt").arg(sequenceNumber++);
    // 设置窗口标题，使用[*]可以在文档被更改后在文件名称后显示"*"号
    setWindowTitle(curFile + "[*]" + tr(" - 多文档编辑器"));
    // 当文档被更改时发射 contentsChanged() 信号，执行 documentWasModified() 槽函数
    connect(document(), SIGNAL(contentsChanged()), this, SLOT(documentWasModified()));
}

// 加载文件
bool MdiChild::loadFile(const QString& fileName)
{
    // 新建 QFile 对象
    QFile file(fileName);

    // 只读方式打开文件，出错则提示，并返回 false
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, tr("多文档编辑器"),
                             tr("无法读取文件 %1:\n%2.").arg(fileName).arg(file.errorString()));
        return false;
    }
    // 新建文本流对象
    QTextStream in(&file);
    // 设置鼠标状态为等待状态
    QApplication::setOverrideCursor(Qt::WaitCursor);
    // 读取文件的全部文本内容，并添加到编辑器中
    setPlainText(in.readAll());
    // 恢复鼠标状态
    QApplication::restoreOverrideCursor();
    // 设置当前文件
    setCurrentFile(fileName);
    connect(document(), SIGNAL(contentsChanged()), this, SLOT(documentWasModified()));
    return true;
}

// 保存操作
bool MdiChild::save()
{
    if (isUntitled)
    {
        // 如果文件未被保存过，则执行另存为操作
        return saveAs();
    }
    else
    {
        // 否则直接保存文件
        return saveFile(curFile);
    }
}

// 另存为操作
bool MdiChild::saveAs()
{
    // 使用文件对话框获取文件路径
    QString fileName = QFileDialog::getSaveFileName(this, tr("另存为"), curFile);
    if (fileName.isEmpty())
    {
        // 如果文件路径为空，则返回 false
        return false;
    }
    // 否则保存文件
    return saveFile(fileName);
}

// 保存文件
// 只保留其中一个定义，保留第一行的定义
bool MdiChild::saveFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::WriteOnly | QFile::Text))
    {
        QMessageBox::warning(this, tr("多文档编辑器"),
                             tr("无法写入文件 %1:\n%2.").arg(fileName).arg(file.errorString()));
        return false;
    }
    QTextStream out(&file);
    QApplication::setOverrideCursor(Qt::WaitCursor);
    out << toPlainText();
    QApplication::restoreOverrideCursor();
    setCurrentFile(fileName);
    return true;
}


// 提取文件名
QString MdiChild::userFriendlyCurrentFile()
{
    // 从文件路径中提取文件名
    return QFileInfo(curFile).fileName();
}

// 文档被更改时，窗口显示更改状态标志
void MdiChild::documentWasModified()
{
    // 根据文档的isModified()函数的返回值，判断编辑器内容是否被更改了
    // 如果被更改了，就要在设置了[*]号的地方显示"*"号，这里会在窗口标题中显示
    setWindowModified(document()->isModified());
}

// 设置字体大小
void MdiChild::setFontSize(int size)
{
    QFont f = font();
    f.setPointSize(size);
    setFont(f);
}

// 设置字体颜色
void MdiChild::setFontColor(const QColor &color)
{
    if (color.isValid()) {
        QTextCharFormat format;
        format.setForeground(color);
        QTextCursor cursor = textCursor();
        if (!cursor.hasSelection()) {
            cursor.select(QTextCursor::Document);
        }
        cursor.mergeCharFormat(format);
        mergeCurrentCharFormat(format);
    }
}

// 设置背景色
void MdiChild::setBackgroundColor(const QColor &color)
{
    if (color.isValid()) {
        QPalette p = palette();
        p.setColor(QPalette::Base, color);
        setPalette(p);
    }
}

// 设置自动换行
void MdiChild::setLineWrap(bool wrap)
{
    if (wrap) {
        setLineWrapMode(QPlainTextEdit::WidgetWidth);
    } else {
        setLineWrapMode(QPlainTextEdit::NoWrap);
    }
}

// 添加这些方法的实现：
QTextBlock MdiChild::firstVisibleBlock() const
{
    return QPlainTextEdit::firstVisibleBlock();
}

QRectF MdiChild::blockBoundingGeometry(const QTextBlock &block) const
{
    return QPlainTextEdit::blockBoundingGeometry(block);
}

QPointF MdiChild::contentOffset() const
{
    return QPlainTextEdit::contentOffset();
}

QRectF MdiChild::blockBoundingRect(const QTextBlock &block) const
{
    return QPlainTextEdit::blockBoundingRect(block);
}
