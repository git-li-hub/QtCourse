#ifndef LINENUMBERAREA_H
#define LINENUMBERAREA_H

#include <QWidget>

class MdiChild;  // 前向声明

class LineNumberArea : public QWidget
{
    Q_OBJECT
public:
    explicit LineNumberArea(MdiChild *editor);  // 移除 = nullptr，因为不能为空

    QSize sizeHint() const override;

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    MdiChild *codeEditor;
};

#endif // LINENUMBERAREA_H
